<?php

namespace App\Policies;

use App\Models\Comment;
use App\Models\User;

class CommentPolicy
{
    public function create(User $user): bool
    {
        return true;
    }

    public function delete(User $user, Comment $comment): bool
    {
        if ($user->role === 'admin') {
            return true;
        }

        return $user->id === $comment->user_id;
    }
}
